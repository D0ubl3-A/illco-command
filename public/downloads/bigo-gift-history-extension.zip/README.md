# BIGO Gift History Exporter

ILLCO-connected Chrome extension for exporting visible gift-history records from:

`https://www.bigo.tv/bigolivepay-recharge/live/history/indexCommonDiamonds.html`

## Install

1. Open Chrome.
2. Go to `chrome://extensions`.
3. Enable `Developer mode`.
4. Click `Load unpacked`.
5. Select this folder: `bigo-gift-history-extension`.

## Use

1. Sign into `https://illcoai.tech/tools/bigo-gift-strategy`.
2. Create an extension token on the ILLCO strategy page.
3. Paste that token into the extension popup and save it.
4. Open the BIGO history URL.
5. Log in manually.
6. Click `Scan page`, `Download CSV`, or `Download JSON`.
7. Paste the JSON export into the ILLCO strategy page to contribute records for strategy.

## Limits

- This does not bypass login, CAPTCHA, region locks, or BIGO security controls.
- It only reads records rendered in your browser.
- Exports are local downloads until the user explicitly contributes the JSON export inside ILLCO.
- The extension verifies an `illcoai.tech` account-issued token before scanning.
- If BIGO changes the page markup, extraction may need selector updates.
