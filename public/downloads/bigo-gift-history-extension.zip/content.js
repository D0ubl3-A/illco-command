const BIGO_EXPORTER = {
  records: [],
  running: false
};

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function cleanText(value) {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function visibleText(element) {
  if (!element) return "";
  const box = element.getBoundingClientRect();
  if (box.width === 0 || box.height === 0) return "";
  return cleanText(element.innerText || element.textContent || "");
}

function looksLikeRecord(text) {
  if (!text || text.length < 8) return false;
  const hasDate = /\b(20\d{2}[-/.]\d{1,2}[-/.]\d{1,2}|\d{1,2}[-/.]\d{1,2}[-/.]20\d{2}|\d{1,2}:\d{2})\b/.test(text);
  const hasValue = /\b(\d+(\.\d+)?\s*(diamond|diamonds|bean|beans|coin|coins|gift|gifts)?|[+$-]?\d{2,})\b/i.test(text);
  const hasGiftWord = /\b(received|gift|diamond|bean|coin|income|host|sender|from)\b/i.test(text);
  return hasDate || (hasValue && hasGiftWord);
}

function candidateElements() {
  const selectors = [
    "table tbody tr",
    "[role='row']",
    ".record",
    ".record-item",
    ".history-item",
    ".list-item",
    ".item",
    "li",
    "tr"
  ];
  const nodes = new Set();
  selectors.forEach((selector) => {
    document.querySelectorAll(selector).forEach((node) => nodes.add(node));
  });
  return Array.from(nodes);
}

function parseTableRow(row) {
  const cells = Array.from(row.querySelectorAll("th,td,[role='cell'],[role='gridcell']")).map(visibleText).filter(Boolean);
  if (cells.length > 1) {
    return {
      source: "table",
      fields: cells,
      raw: cells.join(" | ")
    };
  }
  return null;
}

function parseLooseRecord(element) {
  const table = parseTableRow(element);
  if (table) return table;
  const raw = visibleText(element);
  if (!looksLikeRecord(raw)) return null;
  return {
    source: "visible-text",
    fields: raw.split(/\s{2,}|\n+/).map(cleanText).filter(Boolean),
    raw
  };
}

function extractRecords() {
  const seen = new Set();
  const records = [];

  candidateElements().forEach((element) => {
    const record = parseLooseRecord(element);
    if (!record) return;
    const key = record.raw.toLowerCase();
    if (seen.has(key)) return;
    seen.add(key);
    records.push({
      index: records.length + 1,
      capturedAt: new Date().toISOString(),
      ...record
    });
  });

  BIGO_EXPORTER.records = records;
  return records;
}

async function scrollAndExtract(options = {}) {
  if (BIGO_EXPORTER.running) return BIGO_EXPORTER.records;
  BIGO_EXPORTER.running = true;

  const maxPasses = Math.min(Math.max(Number(options.maxPasses || 120), 5), 400);
  const waitMs = Math.min(Math.max(Number(options.waitMs || 900), 250), 5000);
  let stablePasses = 0;
  let previousCount = 0;
  let previousHeight = 0;

  try {
    window.scrollTo({ top: 0, behavior: "instant" });
    await sleep(waitMs);

    for (let pass = 0; pass < maxPasses; pass += 1) {
      const records = extractRecords();
      const height = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
      const count = records.length;

      if (count === previousCount && height === previousHeight) {
        stablePasses += 1;
      } else {
        stablePasses = 0;
      }

      if (stablePasses >= 5) break;

      previousCount = count;
      previousHeight = height;
      window.scrollTo({ top: height, behavior: "smooth" });
      await sleep(waitMs);
    }

    extractRecords();
    return BIGO_EXPORTER.records;
  } finally {
    BIGO_EXPORTER.running = false;
  }
}

function csvEscape(value) {
  const text = String(value ?? "");
  if (!/[",\n]/.test(text)) return text;
  return `"${text.replace(/"/g, '""')}"`;
}

function toCsv(records) {
  const maxFields = Math.max(0, ...records.map((record) => record.fields.length));
  const headers = ["index", "capturedAt", "source", ...Array.from({ length: maxFields }, (_, index) => `field${index + 1}`), "raw"];
  const rows = records.map((record) => {
    const fields = Array.from({ length: maxFields }, (_, index) => record.fields[index] || "");
    return [record.index, record.capturedAt, record.source, ...fields, record.raw].map(csvEscape).join(",");
  });
  return [headers.join(","), ...rows].join("\n");
}

function downloadText(filename, text, type) {
  const blob = new Blob([text], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

function toStrategyPayload(records) {
  return {
    source: "bigo-gift-history-extension",
    exportedAt: new Date().toISOString(),
    destination: "https://illcoai.tech/tools/bigo-gift-strategy",
    poweredBy: "OpenAI Agent SDK",
    records
  };
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  (async () => {
    const records = await scrollAndExtract(message.options);
    if (message.action === "downloadCsv") {
      downloadText(`bigo-gift-history-${Date.now()}.csv`, toCsv(records), "text/csv;charset=utf-8");
    }
    if (message.action === "downloadJson") {
      downloadText(`bigo-gift-history-strategy-${Date.now()}.json`, JSON.stringify(toStrategyPayload(records), null, 2), "application/json");
    }
    sendResponse({
      ok: true,
      count: records.length,
      message: records.length ? "Records captured." : "No records detected. Make sure you are logged in and the history list is visible."
    });
  })().catch((error) => {
    sendResponse({ ok: false, count: 0, message: error.message });
  });
  return true;
});
