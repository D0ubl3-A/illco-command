const statusEl = document.querySelector("#status");
const resultEl = document.querySelector("#result");
const accountEl = document.querySelector("#account");
const maxPassesEl = document.querySelector("#maxPasses");
const waitMsEl = document.querySelector("#waitMs");
const illcoTokenEl = document.querySelector("#illcoToken");
const ILLCO_TOOL_URL = "https://illcoai.tech/tools/bigo-gift-strategy";
const ILLCO_SESSION_URL = "https://illcoai.tech/api/bigo-gift-strategy/session";
let accountSession = null;

async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function setStatus(message) {
  statusEl.textContent = message;
}

function setResult(message) {
  resultEl.textContent = message;
}

async function checkIllcoSession() {
  try {
    const stored = await chrome.storage.local.get(["illcoBigoToken"]);
    const token = String(illcoTokenEl.value || stored.illcoBigoToken || "").trim();
    if (token && !illcoTokenEl.value) {
      illcoTokenEl.value = token;
    }
    const response = await fetch(ILLCO_SESSION_URL, {
      method: "GET",
      headers: token ? { authorization: `Bearer ${token}` } : {},
      credentials: "include",
      cache: "no-store"
    });
    const data = await response.json();
    accountSession = data;
    if (!data.authenticated) {
      accountEl.textContent = "ILLCO token required before scanning.";
      return false;
    }
    accountEl.textContent = `ILLCO signed in: ${data.user?.email || "verified account"}`;
    return true;
  } catch (_error) {
    accountEl.textContent = "Could not verify ILLCO account. Open ILLCO Strategy first.";
    return false;
  }
}

async function saveToken() {
  const token = String(illcoTokenEl.value || "").trim();
  if (!token) {
    setStatus("Paste the ILLCO extension token first.");
    return;
  }
  await chrome.storage.local.set({ illcoBigoToken: token });
  accountSession = null;
  setStatus("Token saved. Verifying...");
  await checkIllcoSession();
}

async function send(action) {
  const authenticated = accountSession?.authenticated || await checkIllcoSession();
  if (!authenticated) {
    await chrome.tabs.create({ url: ILLCO_TOOL_URL });
    throw new Error("Sign into ILLCO Strategy, then run export again.");
  }

  const tab = await activeTab();
  if (!tab?.id || !tab.url?.startsWith("https://www.bigo.tv/bigolivepay-recharge/live/history/indexCommonDiamonds.html")) {
    throw new Error("Open the BIGO gift history page first.");
  }

  return chrome.tabs.sendMessage(tab.id, {
    action,
    options: {
      maxPasses: Number(maxPassesEl.value || 120),
      waitMs: Number(waitMsEl.value || 900)
    }
  });
}

async function run(action) {
  try {
    setStatus("Running...");
    const response = await send(action);
    setStatus(response.message || "Done.");
    setResult(`${response.count || 0} records found.`);
  } catch (error) {
    setStatus(error.message);
    setResult("");
  }
}

document.querySelector("#scan").addEventListener("click", () => run("scan"));
document.querySelector("#downloadCsv").addEventListener("click", () => run("downloadCsv"));
document.querySelector("#downloadJson").addEventListener("click", () => run("downloadJson"));
document.querySelector("#saveToken").addEventListener("click", saveToken);
document.querySelector("#openIllco").addEventListener("click", () => chrome.tabs.create({ url: ILLCO_TOOL_URL }));
checkIllcoSession();
